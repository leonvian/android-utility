/** Automatically generated file. DO NOT MODIFY */
package com.markupartist.android.widget.actionbar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}